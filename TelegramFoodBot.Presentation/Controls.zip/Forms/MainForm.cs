﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TelegramFoodBot.Business.Interfaces;
using TelegramFoodBot.Business.Services;
using TelegramFoodBot.Entities.Models;
using TelegramFoodBot.Presentation.Controls;

namespace TelegramFoodBot.Presentation.Forms
{
    public partial class MainForm : Form
    {
        private readonly ITelegramService _telegramService;
        private readonly IChatService _chatService;
        private Dictionary<long, ChatControl> _chatControls;
        private long _selectedClientId;

        public MainForm()
        {
            InitializeComponent();

            // Inicializar servicios
            _telegramService = new TelegramService();
            _chatService = new ChatService();
            _chatControls = new Dictionary<long, ChatControl>();

            // Suscribirse a eventos
            _telegramService.MessageReceived += OnMessageReceived;

            // Iniciar el bot
            _telegramService.StartBot();

            // Cargar clientes existentes
            LoadClients();

            // Actualizar título con estado
            this.Text = "Panel de Administración - Bot de Telegram (Conectado)";
        }

        private void LoadClients()
        {
            // Cargar clientes existentes
            var clients = _chatService.GetAllClients();

            foreach (var client in clients)
            {
                AddClientToList(client);
            }
        }

        private void AddClientToList(Client client)
        {
            // Asegurarse de que se ejecuta en el hilo de la UI
            if (InvokeRequired)
            {
                Invoke(new Action(() => AddClientToList(client)));
                return;
            }

            // Añadir cliente a la lista
            var item = new ListViewItem(client.Name);
            item.Tag = client.Id;
            clientsListView.Items.Add(item);

        }

        private void OnMessageReceived(object sender, MessageEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => OnMessageReceived(sender, e)));
                return;
            }

            // Extraer los datos del mensaje sin usar el objeto directamente
            long clientId = e.Message.ClientId;
            string text = e.Message.Text;
            DateTime timestamp = e.Message.Timestamp;
            bool isFromAdmin = e.Message.IsFromAdmin;
            User from = e.Message.From;

            // Verificar si From es null
            if (from == null)
            {
                // Si From es null, usamos ClientId directamente
                // Verificar si ya tenemos este cliente
                if (!_chatControls.ContainsKey(clientId))
                {
                    var client = new Client
                    {
                        Id = clientId,
                        Name = $"Cliente {clientId}",
                        Username = "desconocido"
                    };

                    _chatService.AddClient(client);
                    AddClientToList(client);
                }
            }
            else
            {
                // Si From no es null, procedemos normalmente
                clientId = from.Id;

                // Verificar si ya tenemos este cliente
                if (!_chatControls.ContainsKey(clientId))
                {
                    var client = new Client
                    {
                        Id = clientId,
                        Name = $"{from.FirstName} {from.LastName}",
                        Username = from.Username
                    };

                    _chatService.AddClient(client);
                    AddClientToList(client);
                }
            }

            // Crear un nuevo objeto Message para evitar problemas de conversión
            var newMessage = new TelegramFoodBot.Entities.Models.Message
            {
                Id = e.Message.Id,
                Text = text,
                Timestamp = timestamp,
                IsFromAdmin = isFromAdmin,
                ClientId = clientId,
                From = from
            };

            // Añadir y guardar el mensaje
            _chatControls[clientId].AddMessage(newMessage);
            _chatService.SaveMessage(newMessage);
        }

        private void clientsListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (clientsListView.SelectedItems.Count > 0)
            {
                var selectedItem = clientsListView.SelectedItems[0];
                _selectedClientId = (long)selectedItem.Tag;

                // Ocultar todos los chats
                foreach (var control in _chatControls.Values)
                {
                    control.Visible = false;
                }

                // Mostrar el chat seleccionado
                _chatControls[_selectedClientId].Visible = true;
            }
        }

        

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Detener el bot al cerrar
            _telegramService.StopBot();
        }
    }
}
