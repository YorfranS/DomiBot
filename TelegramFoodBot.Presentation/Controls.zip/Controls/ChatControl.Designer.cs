﻿namespace TelegramFoodBot.Presentation.Controls
{
    partial class ChatControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChatControl));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.paneLENVIARMSJ = new System.Windows.Forms.Panel();
            this.btnENVIARMSJ = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panelCHATROJO = new System.Windows.Forms.Panel();
            this.labelTITLECHAT = new System.Windows.Forms.Label();
            this.panelleftchat = new System.Windows.Forms.Panel();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.labelCLIENTES = new System.Windows.Forms.Label();
            this.panelTOPCHAT = new System.Windows.Forms.Panel();

            this.panel1.SuspendLayout();
            this.panelleftchat.SuspendLayout();
            this.panelCHATROJO.SuspendLayout();
            this.paneLENVIARMSJ.SuspendLayout();
            this.SuspendLayout();

            // panel1
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.paneLENVIARMSJ);
            this.panel1.Controls.Add(this.panelCHATROJO);
            this.panel1.Controls.Add(this.panelleftchat);
            this.panel1.Controls.Add(this.panelTOPCHAT);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1297, 711);
            this.panel1.TabIndex = 0;

            // panel2 (mensajes)
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Location = new System.Drawing.Point(359, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(925, 494);
            this.panel2.TabIndex = 4;

            // paneLENVIARMSJ
            this.paneLENVIARMSJ.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            this.paneLENVIARMSJ.Controls.Add(this.btnENVIARMSJ);
            this.paneLENVIARMSJ.Controls.Add(this.textBox1);
            this.paneLENVIARMSJ.Location = new System.Drawing.Point(359, 632);
            this.paneLENVIARMSJ.Name = "paneLENVIARMSJ";
            this.paneLENVIARMSJ.Size = new System.Drawing.Size(925, 67);
            this.paneLENVIARMSJ.TabIndex = 2;

            // btnENVIARMSJ
            this.btnENVIARMSJ.BackColor = System.Drawing.Color.FromArgb(211, 47, 47);
            this.btnENVIARMSJ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnENVIARMSJ.Font = new System.Drawing.Font("Stencil", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnENVIARMSJ.ForeColor = System.Drawing.Color.White;
            this.btnENVIARMSJ.Image = ((System.Drawing.Image)(resources.GetObject("btnENVIARMSJ.Image")));
            this.btnENVIARMSJ.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnENVIARMSJ.Location = new System.Drawing.Point(768, 6);
            this.btnENVIARMSJ.Name = "btnENVIARMSJ";
            this.btnENVIARMSJ.Size = new System.Drawing.Size(130, 49);
            this.btnENVIARMSJ.TabIndex = 5;
            this.btnENVIARMSJ.Text = "     ENVIAR";
            this.btnENVIARMSJ.UseVisualStyleBackColor = false;
            this.btnENVIARMSJ.Click += new System.EventHandler(this.btnENVIARMSJ_Click);

            // textBox1
            this.textBox1.ForeColor = System.Drawing.Color.Gray;
            this.textBox1.Location = new System.Drawing.Point(17, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(745, 20);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = " Escribe un mensaje...";

            // panelCHATROJO
            this.panelCHATROJO.BackColor = System.Drawing.Color.FromArgb(211, 47, 47);
            this.panelCHATROJO.Controls.Add(this.labelTITLECHAT);
            this.panelCHATROJO.Location = new System.Drawing.Point(12, 14);
            this.panelCHATROJO.Name = "panelCHATROJO";
            this.panelCHATROJO.Size = new System.Drawing.Size(1273, 51);
            this.panelCHATROJO.TabIndex = 3;

            // labelTITLECHAT
            this.labelTITLECHAT.AutoSize = true;
            this.labelTITLECHAT.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelTITLECHAT.ForeColor = System.Drawing.Color.White;
            this.labelTITLECHAT.Location = new System.Drawing.Point(458, 9);
            this.labelTITLECHAT.Name = "labelTITLECHAT";
            this.labelTITLECHAT.Size = new System.Drawing.Size(356, 34);
            this.labelTITLECHAT.Text = "MENSAJES DE CLIENTES";

            // panelleftchat
            this.panelleftchat.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            this.panelleftchat.Controls.Add(this.btnBuscar);
            this.panelleftchat.Controls.Add(this.txtBuscar);
            this.panelleftchat.Controls.Add(this.vScrollBar1);
            this.panelleftchat.Controls.Add(this.labelCLIENTES);
            this.panelleftchat.Location = new System.Drawing.Point(12, 64);
            this.panelleftchat.Name = "panelleftchat";
            this.panelleftchat.Size = new System.Drawing.Size(347, 635);

            // btnBuscar
            this.btnBuscar.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.Font = new System.Drawing.Font("Stencil", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnBuscar.ForeColor = System.Drawing.Color.White;
            this.btnBuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscar.Image")));
            this.btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscar.Location = new System.Drawing.Point(278, 45);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(36, 37);
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);

            // txtBuscar
            this.txtBuscar.ForeColor = System.Drawing.Color.Gray;
            this.txtBuscar.Location = new System.Drawing.Point(15, 53);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(256, 20);
            this.txtBuscar.Text = " Buscar cliente...";

            // vScrollBar1
            this.vScrollBar1.Location = new System.Drawing.Point(329, 3);
            this.vScrollBar1.Size = new System.Drawing.Size(18, 632);

            // labelCLIENTES
            this.labelCLIENTES.AutoSize = true;
            this.labelCLIENTES.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold);
            this.labelCLIENTES.ForeColor = System.Drawing.Color.Black;
            this.labelCLIENTES.Location = new System.Drawing.Point(113, 13);
            this.labelCLIENTES.Text = "CLIENTES";

            // panelTOPCHAT
            this.panelTOPCHAT.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            this.panelTOPCHAT.Location = new System.Drawing.Point(359, 65);
            this.panelTOPCHAT.Size = new System.Drawing.Size(925, 72);

            // ChatControl
            this.Controls.Add(this.panel1);
            this.Name = "ChatControl";
            this.Size = new System.Drawing.Size(1297, 711);
            this.panel1.ResumeLayout(false);
            this.panelleftchat.ResumeLayout(false);
            this.panelleftchat.PerformLayout();
            this.panelCHATROJO.ResumeLayout(false);
            this.panelCHATROJO.PerformLayout();
            this.paneLENVIARMSJ.ResumeLayout(false);
            this.paneLENVIARMSJ.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelleftchat;
        private System.Windows.Forms.Panel panelTOPCHAT;
        private System.Windows.Forms.Panel panelCHATROJO;
        private System.Windows.Forms.Label labelTITLECHAT;
        private System.Windows.Forms.Panel paneLENVIARMSJ;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Label labelCLIENTES;
        private System.Windows.Forms.Button btnENVIARMSJ;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Button btnBuscar;
    }
}
