﻿using System;
using System.Drawing;
using System.Windows.Forms;
using TelegramFoodBot.Entities.Models;
// Añadir este alias para evitar ambigüedad
using AppMessage = TelegramFoodBot.Entities.Models.Message;

namespace TelegramFoodBot.Presentation.Controls
{
    public partial class ChatControl : UserControl
    {
        private const int MessagePadding = 10;
        private const int MessageMargin = 5;
        private const int MaxMessageWidth = 300;

        public ChatControl()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }

        private void btnENVIARMSJ_Click(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }


        public void AddMessage(TelegramFoodBot.Entities.Models.Message message)
        {
            // Crear panel para el mensaje
            var messagePanel = new Panel();
            messagePanel.AutoSize = true;
            messagePanel.MaximumSize = new Size(MaxMessageWidth, 0);
            messagePanel.Padding = new Padding(MessagePadding);
            messagePanel.Margin = new Padding(MessageMargin);

            // Crear etiqueta para el texto del mensaje
            var messageLabel = new Label();
            messageLabel.Text = message.Text;
            messageLabel.AutoSize = true;
            messageLabel.MaximumSize = new Size(MaxMessageWidth - (MessagePadding * 2), 0);
            messagePanel.Controls.Add(messageLabel);

            // Crear etiqueta para la hora
            var timeLabel = new Label();
            timeLabel.Text = message.Timestamp.ToString("HH:mm");
            timeLabel.AutoSize = true;
            timeLabel.Font = new Font(timeLabel.Font.FontFamily, 8);
            timeLabel.ForeColor = Color.Gray;
            timeLabel.Dock = DockStyle.Bottom;
            messagePanel.Controls.Add(timeLabel);

            // Ajustar apariencia según el remitente
            if (message.IsFromAdmin)
            {
                messagePanel.BackColor = Color.LightBlue;
                messagePanel.Dock = DockStyle.Right;
            }
            else
            {
                messagePanel.BackColor = Color.WhiteSmoke;
                messagePanel.Dock = DockStyle.Left;
            }

            //// Añadir al panel de mensajes
            //messagesFlowLayoutPanel.Controls.Add(messagePanel);

            //// Desplazar hacia abajo para mostrar el mensaje más reciente
            //messagesFlowLayoutPanel.ScrollControlIntoView(messagePanel);
        }
    }
}
